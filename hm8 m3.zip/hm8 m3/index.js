
const titleInp = document.querySelector("#title");
const searchInput = document.getElementById("searchInput");
const descriptionInp = document.querySelector("#description");
const priceInp = document.querySelector("#price");
const form = document.querySelector(".form");
const updateBtn = document.querySelector("#update");
const products = document.querySelector(".products");
const categorySelect = document.querySelector("#categorySelect");
const filterSelect = document.querySelector("#filter");

const cartModal = document.querySelector("#cartModal");
const cartContent = document.querySelector("#cartContent");
const openCartButton = document.querySelector("#openCart");
const closeCartButton = document.querySelector("#closeCart");

let allProducts = [];
let cart = [];

async function getData(category = "", sortType = "") {
  try {
    const response = await fetch(`http://localhost:3000/products${category ? "?" + `category=${category}` : ""}`);
    const data = await response.json();
    allProducts = data;
    displayData(data, sortType);
  } catch (error) {
    console.error("Ошибка при получении данных:", error);
  }
}

function displayData(data, sortType) {

  products.innerHTML = "";

  const sortedData = sortProducts(data, sortType);

  sortedData.forEach((item) => {
    const productElement = createProductElement(item);
    products.appendChild(productElement);
  });
}

function sortProducts(data, sortType) {
  const sortedData = [...data]; 
  if (sortType === "cheaper") {
    sortedData.sort((a, b) => a.price - b.price);
  } else if (sortType === "expensive") {
    sortedData.sort((a, b) => b.price - a.price);
  }
  return sortedData;
}

function createProductElement(item) {
  const productElement = document.createElement("div");
  productElement.className = "product";
  productElement.innerHTML = `
    <img src="${item.image}" />
    <h2>${item.title}</h2>
    <p>${item.description}</p>
    <b>${item.price}</b>
    <button class="edit-btn" data-id="${item.id}">Edit</button>
    <button class="add-to-cart-btn" data-id="${item.id}">Add to Cart</button>
  `;

  const editButton = productElement.querySelector(".edit-btn");
  editButton.addEventListener("click", () => editProduct(item.id));

  const addToCartButton = productElement.querySelector(".add-to-cart-btn");
  addToCartButton.addEventListener("click", () => addToCart(item));

  return productElement;
}

function openCart() {
  cartModal.style.display = "block";
  displayCart();
}

function closeCart() {
  cartModal.style.display = "none";
}

function addToCart(item) {
  cart.push(item);
  displayCart();
}

function displayCart() {
  cartContent.innerHTML = "";
  let total = 0;

  cart.forEach((item) => {
    const cartItem = document.createElement("div");
    cartItem.className = "cart-item";
    cartItem.innerHTML = `
      <h3>${item.title}</h3>
      <p>${item.description}</p>
      <p>Price: $${item.price}</p>
    `;
    cartContent.appendChild(cartItem);
    total += item.price;
  });

  const totalElement = document.createElement("div");
  totalElement.className = "cart-total";
  totalElement.textContent = `Total: $${total}`;
  cartContent.appendChild(totalElement);
}

function editProduct(itemId) {
  const itemToEdit = allProducts.find((item) => item.id === itemId);

  if (itemToEdit) {
    titleInp.value = itemToEdit.title;
    descriptionInp.value = itemToEdit.description;
    priceInp.value = itemToEdit.price;

    updateBtn.addEventListener("click", () => updateProduct(itemId));
  }
}

function updateProduct(itemId) {
  const updatedTitle = titleInp.value;
  const updatedDescription = descriptionInp.value;
  const updatedPrice = parseFloat(priceInp.value);

  const updatedItem = {
    title: updatedTitle,
    description: updatedDescription,
    price: updatedPrice,
  };

  fetch(`http://localhost:3000/products/${itemId}`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(updatedItem),
  })
    .then((response) => response.json())
    .then(() => {
      getData(); 
    })
    .catch((error) => {
      console.error("Ошибка при обновлении товара:", error);
    });
}

searchInput.addEventListener("input", () => {
  const searchString = searchInput.value.trim().toLowerCase();
  const filteredProducts = allProducts.filter((product) =>
    product.title.toLowerCase().includes(searchString)
  );
  displayData(filteredProducts);
});

categorySelect.addEventListener("change", () => {
  const selectedCategory = categorySelect.value;
  getData(selectedCategory);
});

filterSelect.addEventListener("change", () => {
  const selectedFilter = filterSelect.value;
  displayData(allProducts, selectedFilter);
});

openCartButton.addEventListener("click", openCart);
closeCartButton.addEventListener("click", closeCart);

getData();


